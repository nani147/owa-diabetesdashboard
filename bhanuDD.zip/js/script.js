$(document).ready(function() {
    $('#example').DataTable( {
      "autoWidth": true
    } );
} );
